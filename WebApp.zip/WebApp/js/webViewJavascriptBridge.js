/**
 * Created by wxl on 2016/06/18.
 */
var bridge = {
    rels: {},
    bridge: null,
    eventCallbacks: {},
    headers: {},
    send: function () {
    }
};
function connectWebViewJavascriptBridge(callback) {
    if (window.WebViewJavascriptBridge) {
        callback(WebViewJavascriptBridge)
    } else {
        document.addEventListener('WebViewJavascriptBridgeReady', function () {
            callback(WebViewJavascriptBridge)
        }, false)
    }
}

connectWebViewJavascriptBridge(function (bridge) {
    window.bridge.bridge = bridge;
    bridge.init(function (messageJson, responseCallback) {
        var message = JSON.parse(messageJson);
        if (message.rel) {
            var func = window[message.rel];
            if (!func) {
                if (window.bridge.rels[message.rel]) {
                    var funcName = window.bridge.rels[message.rel];
                    if (funcName) {
                        func = window.bridge[funcName];
                        if (!func) {
                            func = window[funcName];
                        }
                    }
                }
            }
            if (func) {
                var callback = message.callback;
                var messageData;
                try{
                    if(typeof message.data == 'string') {
                        messageData = JSON.parse(message.data);
                    }else{
                        messageData = message.data;
                    }
                }
                catch(e){
                }
                func(messageData, callback, responseCallback);
            }
        }

    });
    var processEventName = function (eventName) {
        return 'on' + eventName.substring(0, 1).toUpperCase() + eventName.substring(1);
    };
    window.bridge.registerAppEvent = function (eventName, callback) {
        window.bridge[processEventName(eventName)] = callback;
        bridge.send({
                rel: 'app.registerEvent',
                data: {
                    eventName: eventName,
                    callback: processEventName(eventName)
                },
                callback: null
            },
            function (responseData) {

            });
        //}

    };
    window.bridge.unregisterAppEvent = function (eventName) {
        bridge.send({
                rel: 'app.unregisterEvent',
                data: {
                    eventName: eventName
                },
                callback: null
            },
            function (responseData) {

            });
        delete window.bridge[processEventName(eventName)];
    };
    window.bridge.send = function (data, callback) {
        var sendData = data;
        if (typeof sendData != 'String') {
            sendData = JSON.stringify(data);
        }
        bridge.send(sendData, function (responseData) {
            if (callback) {
                callback(responseData);
            }
        })
    };
    window.bridge.send({rel: 'js.getHeaders'}, function (data) {
        window.bridge.headers = JSON.parse(data);
    });
    if (window.bridge.onBridgeReady) {
        setTimeout(function () {
            window.bridge.onBridgeReady()
        }, 100);
    }
    // bridge.registerHandler('testJavascriptHandler', function (data, responseCallback) {
    //     log('ObjC called testJavascriptHandler with', data)
    //     var responseData = {'Javascript Says': 'Right back atcha!'}
    //     log('JS responding with', responseData)
    //     responseCallback(responseData)
    // })
});
