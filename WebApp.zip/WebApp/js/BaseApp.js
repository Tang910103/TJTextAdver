﻿//var interfaceUrl = "http://54.169.70.4:12341/AppHandler.ashx?service=";  // 测试地址
var interfaceUrl = "http://52.220.148.234:12341/AppHandler.ashx?service=";  // 测试地址

//var interfaceUrl = "http://58.30.70.246/AppHandler.ashx?service=";     //  正式地址
//var interfaceUrl = "http://localhost:60086/AppHandler.ashx?service=";     //  本地测试地址
//var interfaceUrl = "http://54.169.70.4:82/AppHandler.ashx?service=";    //后台新说的url
var token = "12345678";
window.userToken = "";
//window.userToken = "cf179e1d04011e9c18a7d70a955722678fb860c50fd3c71e";
//window.userToken = "MkE1NDkyMTctRTlFRS00NUQ4LTgwREItRUEzM0U4MjFFRTQ5dnFqdDd6U2NN";
//window.userToken = "NDM0OURCQTItNENDOC00NDBBLUE1MTEtN0VCMjlCMjI4NDI3TWlZTGJSdVFL"
//window.userToken = "NDM0OURCQTItNENDOC00NDBBLUE1MTEtN0VCMjlCMjI4NDI3TWdBOEY3QVVi"
//window.userToken = "NUY1QjQ0QkEtQjkwNS00ODJELTlCQjAtQkM0QzRGRDIxN0MzV1J6UkpBSXFL";//正式
//window.userToken = "MDFDQzEwNzItNjIxQi00RDUzLUIxQjQtMUM3REU4NzBBMjNEcnJRekdraTRO";//正式
//window.userToken = "MkE1NDkyMTctRTlFRS00NUQ4LTgwREItRUEzM0U4MjFFRTQ5UVBVNUx2NlFz";//正式
//window.userToken = "MkE1NDkyMTctRTlFRS00NUQ4LTgwREItRUEzM0U4MjFFRTQ5eFpYYmg0c2lX";
//window.userToken = "NDM0OURCQTItNENDOC00NDBBLUE1MTEtN0VCMjlCMjI4NDI3NWVvOVhtME10"; //娇娇测试库
//window.userToken = "NzZGRDRFMUMtRjMwRS00NEUzLTkyRjYtRENGRjk3ODQ4NzcyR0w1THVTeFhZ";
//window.userToken = "cf179e1d04011e9c5c7611ae51c219434e634c2008dab77b";
// window.userToken = "01850c9123d3b8c0622c6132557f8120fc00650c72b3668f";
function setAngularJS() {
    app.factory('HttpInterceptor', ['$q', HttpInterceptor]);
    function HttpInterceptor($q) {
        return {
            request: function (config) {
                return config;
            },
            requestError: function (err) {
                return $q.reject(err);
            },
            response: function (res) {
                return res;
            },
            responseError: function (err) {
                if (-1 === err.status) {
                    Appalert("访问服务无响应，地址错误！");
                    // 远程服务器无响应
                } else {
                    Appalert("访问服务状态：" + err.status + "，访问状态内容：" + err.statusText + "，数据内容：" + err.data);
                }
                return $q.reject(err);
            }
        };
    }
    app.config(['$httpProvider', function ($httpProvider) {
        $httpProvider.interceptors.push(HttpInterceptor);
    }]);
    app.config(function ($httpProvider) { // CORS post跨域配置
        $httpProvider.defaults.useXDomain = true;
        $httpProvider.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded;charset=utf-8';
        var param = function (obj) {  // 修改angularjs $http.post的默认传参方式
            var query = '', name, value, fullSubName, subName, subValue, innerObj, i;

            for (name in obj) {
                value = obj[name];

                if (value instanceof Array) {
                    for (i = 0; i < value.length; ++i) {
                        subValue = value[i];
                        fullSubName = name + '[' + i + ']';
                        innerObj = {};
                        innerObj[fullSubName] = subValue;
                        query += param(innerObj) + '&';
                    }
                }
                else if (value instanceof Object) {
                    for (subName in value) {
                        subValue = value[subName];
                        fullSubName = name + '[' + subName + ']';
                        innerObj = {};
                        innerObj[fullSubName] = subValue;
                        query += param(innerObj) + '&';
                    }
                }
                else if (value !== undefined && value !== null)
                    query += encodeURIComponent(name) + '=' + encodeURIComponent(value) + '&';
            }

            return query.length ? query.substr(0, query.length - 1) : query;
        };

        $httpProvider.defaults.transformRequest = [function (data) {
            return angular.isObject(data) && String(data) !== '[object File]' ? param(data) : data;
        }];

        delete $httpProvider.defaults.headers.common['X-Requested-With'];
    });
    //转化为HTML5文本
    app.filter('trust2Html', ['$sce', function ($sce) {
        return function (val) {
            return $sce.trustAsHtml(val);
        };
    }])
}

function getUserToken(obj, url, callback, errorcallback) {
    if (window.userToken.length <= 0) {
        bridge.send({ rel: 'js.getHeaders' }, function (data) {
            data = JSON.parse(data);
            if (data != null) {
                window.userToken = data.Token;
                obj.token = window.userToken;

                var sjson = funcData(obj);
                $.ajax({
                    url: url,
                    type: 'post',
                    dataType: "json",
                    data: sjson,
                    timeout: 20000,
                    success: function (data) {
                        callback(data);
                    },
                    //error: function (data) {

                    //    Appalert(data.responseText);
                    //},
                    error: function (jqXHR, textStatus, errorThrown) {
                        if (textStatus == "timeout") {
                            Appalert("加载超时，请重试");
                        } else {
                            Appalert(textStatus);
                        }
                        if (errorcallback != undefined)
                            errorcallback;
                    }
                });
            } else {
                Appalert("app中登录码获取错误！");
            }
        });
    } else {
        obj.token = window.userToken;
        var sjson = funcData(obj);
        $.ajax({
            url: url,
            type: 'post',
            dataType: "json",
            timeout: 20000,
            data: sjson,
            success: function (data) {
                callback(data);
            },
            //error: function (data) {
            //    Appalert(data.responseText);
            //}
            error: function (jqXHR, textStatus, errorThrown) {
                if (textStatus == "timeout") {
                    Appalert("加载超时，请重试");
                } else {
                    Appalert(textStatus);
                }
                if (errorcallback != undefined)
                    errorcallback();
            }
        });
    }
}
function angularJSpostJson($scope, $http, obj, url, callback, buttonCallback) {
    if (window.userToken.length <= 0) {
        bridge.send({ rel: 'js.getHeaders' }, function (data) {
            if (data != null) {
                data = JSON.parse(data);
                window.userToken = data.Token;
                obj.token = window.userToken;
                var sjson = funcData(obj);
                $http.post(url, sjson)
                .success(function (response) {
                    if (successData(response)) {
                        callback($scope, response.data);
                    }
                });
            } else {
                Appalert("app中登录码获取错误！");
            }
        });
    } else {
        obj.token = window.userToken;
        var sjson = funcData(obj);
        $http.post(url, funcData(obj))
                .success(function (response) {
                    if (buttonCallback != undefined)
                        buttonCallback(response);
                    if (successData(response)) {
                        callback($scope, response.data);
                    }
                });
    }

}
function angularJSpostJsonNO($scope, $http, obj, url, callback, buttonCallback) {
        bridge.send({ rel: 'js.getHeaders' }, function (data) {
            if (data != null) {
                data = JSON.parse(data);
                var sjson = funcData(obj);
                $http.post(url, sjson)
                .success(function (response) {
                    if (successData(response)) {
                        callback($scope, response.data);
                    }
                });
            } else {
                Appalert("app中登录码获取错误！");
            }
        });
}
function angularJSpostJsonNew($scope, $http, obj, url, callback, buttonCallback) {
    if (window.userToken.length <= 0) {
        bridge.send({ rel: 'js.getHeaders' }, function (data) {
            if (data != null) {
                data = JSON.parse(data);
                window.userToken = data.Token;
                obj.token = window.userToken;
                var sjson = funcData(obj);
                $http.post(url, sjson)
                .success(function (response) {
                    if (successData(response)) {
                        callback($scope, response);
                    }
                });
            } else {
                Appalert("app中登录码获取错误！");
            }
        });
    } else {
        obj.token = window.userToken;
        var sjson = funcData(obj);
        $http.post(url, funcData(obj))
                .success(function (response) {
                    if (buttonCallback != undefined)
                        buttonCallback(response);
                    if (successData(response)) {
                        callback($scope, response);
                    }
                });
    }

}

//调用原生分享接口
function shareInvoke(url){
  
    bridge.send({ rel: 'js.share',data:url});
}

function successData(data) {
    if (data.apiStatus != 0) {
        Appalert(data.info);
        return false;
    }
    if (data.sysStatus != 0) {
        Appalert(data.info);
        return false;
    }
    return true;
}
//function successData(data) {
//    if (data.apiStatus != 0) {
//        alert(data.info);
//        return false;
//    }
//    if (data.sysStatus != 0) {
//        alert(data.info);
//        return false;
//    }
//    return true;
//}
//补充0
function fix(num, length) {
    return ('' + num).length < length ? ((new Array(length + 1)).join('0') + num).slice(-length) : '' + num;
}
function timest() {
    var tmp = Date.parse(new Date()).toString();
    tmp = tmp.substr(0, 10);
    return parseInt(tmp);
}
function funcData(data) {

    function objKeySort(obj) {//排序的函数
        var getProperties = {};
        //将对象keys获取
        var objKey = Object.keys(obj).sort();
        for (var i = 0; i < objKey.length; i++) {
            var name = objKey[i];
            var value = obj[name];
            if (value instanceof Array) {
                $.each(value, function (j) {
                    var item = value[j];
                    var objItemKey = Object.keys(item).sort();
                    for (var k = 0; k < objItemKey.length; k++) {
                        var itemName = objItemKey[k];
                        var itemValue = item[itemName];
                        var newItemName = name + "[" + fix(j, 3) + "]." + itemName;
                        if (String(itemValue).length > 0)
                            getProperties[newItemName] = itemValue;

                    }
                });
            } else if (value instanceof Object) {
                var valueKey = Object.keys(value).sort();
                for (var j = 0; j < valueKey.length; j++) {
                    var valuename = valueKey[j];
                    var valuevalue = value[valuename];
                    if (String(valuevalue).length > 0)
                        getProperties[name + "." + valuename] = valuevalue;
                }
            } else {
                if (String(value).length > 0)
                    getProperties[name] = value;
            }
        }
        return getProperties;
        //var newKey = Object.keys(getProperties).sort();
        //newKey.sort(function (a, b) { return a + "" > b + ""; });
        ////先用Object内置类的keys方法获取要排序对象的属性名，再利用Array原型上的sort方法对获取的属性名进行排序，newkey是一个数组
        //var newObj = {};//创建一个新的对象，用于存放排好序的键值对
        //for (var i = 0; i < newKey.length; i++) {//遍历newkey数组
        //    var keyName = newKey[i];
        //    newObj[keyName] = getProperties[keyName];//向新创建的对象中按照排好的顺序依次增加键值对
        //}
        //return newObj;//返回排好序的新对象
    }
    function sortObjectAndParseParam(obj) {
        var paramStr = "";
        var keys = Object.keys(obj).sort();
        for (var i = 0; i < keys.length; i++) {
            paramStr += keys[i] + "=" + obj[keys[i]] + "&";
        }
        var bizParas = paramStr.substr(0, paramStr.length - 1);
        return bizParas;
    }
    var parseParam = function (param, key) {
        var paramStr = "";
        if (param instanceof String || param instanceof Number || param instanceof Boolean) {
            //if (param.length > 0)
            paramStr += "&" + key + "=" + param;
        } else {
            $.each(param, function (i) {
                var k = key == null ? i : key + (param instanceof Array ? "[" + i + "]" : "." + i);
                paramStr += '&' + parseParam(this, k);
            });
        }
        return paramStr.substr(1);
    };

    //将兑换转化为url参数类型
    var newObj = objKeySort(data);
    //var val = parseParam(newObj);
    var val = sortObjectAndParseParam(newObj);

    //时间戳
    var timestamp = timest();
    //统一传入参数格式
    var obj = new Object();
    obj.ver = "1.0";
    var urlin = encodeURIComponent(val + timestamp + token);
    obj.sign = String($.param(urlin)).toUpperCase();
    obj.data = data;
    obj.timestamp = timestamp;
    return JSON.stringify(obj);
}
//App跳转本地URL
function reUrl(text, locationHref) {
    var obj = new Object();
    obj.text = text;
    obj.method = 'GET';
    obj.href = locationHref;
    if (locationHref.indexOf("http://") >= 0 || locationHref.indexOf("https://") >= 0) {
        obj.rel = 'app.pt.html5';
    } else {
        obj.rel = 'app.pt.native.html5';
    }

    bridge.send({ rel: 'app.pt.native.html5', data: obj });
}
//App跳转本地URL
function reUrl2(text, locationHref) {
    var obj = new Object();
    obj.text = text;
    obj.method = 'GET';
    obj.href = locationHref;
    obj.rel = 'app.pt.html5';
    obj.needTitle = true;
    bridge.send({ rel: 'app.pt.native.html5', data: obj });
}

//跳转到登录页
function reLoginUrl() {
    bridge.send({ rel: 'app.pt.login' });
}
//跳转到首页
function reFirstUrl() {
    bridge.send({ rel: 'app.pt.main' });
}
//关闭所有H5
function closeAllH5()
{
    bridge.send({ rel: 'app.pt.close.all' });
}
bridge.rels['web.refresh'] = 'onRefresh';
var onRefresh = function (data, callback, responseCallback) {
    bridge.send({
        rel: 'js.closeOK'
    });
};

bridge.rels['web.refresh1'] = 'reFirstUrl';

function AppRefresh(msg) {
    bridge.send({
        rel: 'js.dialog',
        title: "提示",
        content: msg,
        data: [{
            rel: 'web.refresh',
            title: '确认'
        }]
    });
}
//跳转到首页
function AppRefreshMain(msg) {
    bridge.send({
        rel: 'js.dialog',
        title: "提示",
        content: msg,
        data: [{
            rel: 'web.refresh1',
            title: '确认'
        }]
    });
}


//App弹出提示框
function Appalert(msg) {
    //alert(msg);
   bridge.send({ rel: 'js.toast', data: msg });
}
//判断身份证号正则
function isCardNo(card) {
    // 身份证号码为15位或者18位，15位时全为数字，18位前17位为数字，最后一位是校验位，可能为数字或字符X  
    var reg = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;
    if (reg.test(card) === false) {
        Appalert("身份证号不合法！");
        return false;
    } else {
        return true;
    }
}
//判断手机号正则
function checkphone(phone) {
    var reg = /^(1)[\d]{10}$/;
    if (!reg.test(phone)) {
        Appalert("手机号不合法!");
        return false;
    } else {
        return true;
    }
}
//验证邮编正则
function is_postcode(postcode) {
    if (postcode == "") {
        Appalert("请输入邮件!");
        return false;
    } else {
        if (! /^[0-9][0-9]{5}$/.test(postcode)) {
            Appalert("请输入正确邮编!");
            return false;
        }
    }
    return true;
}
//检查日期格式
function RQcheck(RQ) {
    var date = RQ;
    var result = date.match(/^(\d{1,4})(-|\/)(\d{1,2})\2(\d{1,2})$/);

    if (result == null)
        return false;
    var d = new Date(result[1], result[3] - 1, result[4]);
    return (d.getFullYear() == result[1] && (d.getMonth() + 1) == result[3] && d.getDate() == result[4]);

}
//获取Url参数
function request(paras) {
    var url = location.href;
    var paraString = url.substring(url.indexOf("?") + 1, url.length).split("&");
    var paraObj = {}
    for (i = 0; j = paraString[i]; i++) {
        paraObj[j.substring(0, j.indexOf("=")).toLowerCase()] = j.substring(j.indexOf("=") + 1, j.length);
    }
    var returnValue = paraObj[paras.toLowerCase()];
    if (typeof (returnValue) == "undefined") {
        return "";
    } else {
        return returnValue;
    }
}