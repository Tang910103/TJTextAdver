<?php
/**
 * git 增量打包脚本.系统必须支持 git,php,zip 命令
 * 脚本参数:  git分支名  开始git节点  结束git节点  打包文件名
 * git节点指git版本号或tag,打包文件名可以包含路径
 * 运行路径: 将 pack.php 放到工程根目录,然后进入工程根目录运行php执行 pack.php 脚本
 * 示例:  php pack.php master v1.0.0 v1.0.1  pack-v1.0.1 path
 */


$branch = $argv[1];
$start_flag = $argv[2];
$end_flag = $argv[3];
$pack_file_name = $argv[4];
$pack_path = $argv[5];
$file_path = dirname(__FILE__).'/';
$git_cmd = <<<EOT
git diff $start_flag  $end_flag  --name-status
EOT;
$git_ret = shell_exec($git_cmd);
var_dump($git_ret);
$file_arr = explode("\n",$git_ret);
$add_files = '';
foreach ($file_arr as $f)
{
    if(empty($f))
    {
        continue;
    }
    $f_info = explode("\t",$f);

    //删除的文件,不打包
    if($f_info[0]=='D')
    {
        continue;
    }
    $add_files .= $f_info[1]."\t";
}
var_dump($file_arr);
$pack_cmd = <<<EOT
git archive $branch $add_files -o $pack_path/$pack_file_name.zip
EOT;

$git_ret = shell_exec($pack_cmd);
echo "pack success! pack file:  $pack_file_name.zip\n";

