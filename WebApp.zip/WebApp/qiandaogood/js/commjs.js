﻿//function ResumeError() { return true; }
//window.onerror = ResumeError;

$(document).ready(function () {

    //common
    try {

        $(window).resize(function () {

        });

        $(window).scroll(function () {

        });

        


        $("a.re_top").click(function () {
            $('body,html').animate({ scrollTop: 0 }, 1000);
            return false;
        });

    }
    catch (e) { }

    


});
