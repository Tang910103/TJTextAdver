﻿//function ResumeError() { return true; }
//window.onerror = ResumeError;


