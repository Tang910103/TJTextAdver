﻿function sendMsg(chenkedid) {
    //"check":1 验证手机号是否已注册
    var url = interfaceUrl + "html5.sendMessage";
    var yzm = "";
    var obj = new Object();
    var iRand = Math.floor(Math.random() * 991 + 10);
    var iRand2 = Math.floor(Math.random() * 4001 + 1000);
    var iinx = Math.random() * 8
    yzm += String(iRand).substr(0, 2);
    yzm += String(iRand2).substr(0, 2);
    yzm += $("#phone").val().substr(iinx, 2);
    obj.mobile = $("#phone").val();
    obj.verify = yzm;
    obj.check = chenkedid;
    $("#hf_yzm").val(yzm);
    var callback = function (data) {
        if (successData(data)) {
            //$("#yzm").val(obj.verify);
            count = data.data.seconds;
            sendMessage();
            sendPhone = $("#phone").val();
       }
    };
    getUserToken(obj, url, callback);
}

function findPhoneCard(msg) {
    var url = interfaceUrl + "html5.getCardCode";
    var obj = new Object();
    obj.mobile = $("#phone").val();
    var callback = function (data) {
        $("#ok").prop("disabled", false).val("完成");
        if (successData(data)) {
            if (data.data.length > 0) {
                $("#register").hide();
                $("#card").show();
                $("#titlename").html("绑定会员卡");
                $("#passwordbox").hide();
                var tp_code = "";
                for (var i = 0; i < data.data.length; i++) {
                    if (data.data.length == 1)
                    {
                        tp_code += "<li class=\"band_red\"><img src=\"image/icon_03.png\" class=\"img_card_type band_red \" /><label>" + data.data[i].vipTypeName + "</label><span>" + data.data[i].cardCode + "</span></li>";
                        hybd_nr1_on = i;
                        //$("li").addClass("band_red");
                    }
                    else
                    {
                        tp_code += "<li><img src=\"image/icon_03.png\" class=\"img_card_type\" /><label>" + data.data[i].vipTypeName + "</label><span>" + data.data[i].cardCode + "</span></li>";
                    }
                    //tp_code += "<li><img src=\"image/icon_03.png\" class=\"img_card_type\" /><label>" + data.data[i].vipTypeName + "</label><span>" + data.data[i].cardCode + "</span></li>";
               }
                $("#card ul").html(tp_code);
                $("#card ul li").each(function (i, e) {
                    $(this).click(function () {
                        if (hybd_nr1_on != i) {
                            $(this).closest("#card").find("ul li").eq(hybd_nr1_on).removeClass("band_red");
                            $(this).addClass("band_red");
                            hybd_nr1_on = i;
                        }
                    });
                });
            } else {
                register();
                //if (msg != undefined)
                //    Appalert("你没有会员卡，无法进行绑定！");
                //else
                //    register();
                //if (msg != undefined)
                //    register();
                //else {
                //    $("#register").hide();
                //    $("#passwordbox").show();
                //}
            }
        }
    };
    var errorcallback = function () {
        $("#ok").prop("disabled", false).val("完成");
    }
    getUserToken(obj, url, callback, errorcallback);
}

var onSure = function (data, callback, responseCallback) {
    //跳转到会员中心
    bridge.send({ rel: 'event.refreshUser' });
    bridge.send({ rel: 'js.close' });
};
function register() {
    if ($("#card").is(":visible")) {
        if (hybd_nr1_on == -1) {
            Appalert("请选择您要绑定的会员卡！");
            return;
        }
    }

    bridge.rels['web.ok'] = 'onSure';
    var url = interfaceUrl + "html5.openCard";
    var obj = new Object();
    if ($("#birthday").val() != undefined && $("#birthday").val().length>0)
        obj.birthDay = $("#birthday").val();
    obj.mobile = $("#phone").val();
    if ($("#nickname").val() != undefined && $("#nickname").val().length > 0)
        obj.nickname = $("#nickname").val();
    if ($("#psw").val() != undefined)
        obj.password = $("#psw").val();
    if ($("#hf_sex").val() != undefined && $("#hf_sex").val().length > 0)
        obj.sex = $("#hf_sex").val();
    if (hybd_nr1_on != -1) {
        if ($("#card .band_card ul li.band_red span").html() != undefined)
            obj.vipCode = $("#card .band_card ul li.band_red span").html();
    }
    if ($("#hf_photo").val() != undefined)
        obj.userPhoto = $("#hf_photo").val();

    //if ($("#sfzhm").val() != undefined && $("#sfzhm").val().length > 0)
    //    obj.idNo = $("#sfzhm").val();
    obj.idNo ="";

    $("#ok").prop("disabled", true).val("提交中...");
    $("#finish").prop("disabled", true).val("提交中...");
    var callback = function (data) {
        $("#ok").prop("disabled", false).val("完成");
        $("#finish").prop("disabled", false).val("完成");
        if (successData(data)) {
            var note = "";
            if (hybd_nr1_on != -1) {
                if ($("#card .band_card ul li.band_red span").html() != undefined)
                    note = "恭喜您注册成功！";
            } else {
                note = "恭喜您成为电子会员！";
            }
            bridge.send({
                rel: 'js.dialog',
                title: "提示",
                content: note,
                data: [
                    { rel: 'web.ok', title: '确认' }
                ]
            });
        }
    };
    var errorcallback = function () {
        $("#ok").prop("disabled", false).val("完成");
        $("#finish").prop("disabled", false).val("完成");
    }
    getUserToken(obj, url, callback, errorcallback);
}

function successData(data) {
    if (data.apiStatus != 0) {
        Appalert(data.info);
        return false;
    }
    if (data.sysStatus != 0) {
        Appalert(data.info);
        return false;
    }
    return true;
}