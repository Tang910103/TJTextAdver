
function defaultMinheight(elemet){
		var windowHeight=parseInt($(window).height());
		$(elemet).css({
			"height":(windowHeight-28)+"px"
		})	
}

var addandplus=function(add,plus,inputshow){
	// var number=parseInt($(inputshow).val());
	$(add).bind("click",function(){
		var number= parseInt($(this).parent().find(inputshow).val());
		number+=1
		$(this).parent().find(inputshow).val(number)
	})
	$(plus).bind("click",function(){
		var number= parseInt($(this).parent().find(inputshow).val());
		if(number<=1){
			return false
		}else{
			number-=1
			$(this).parent().find(inputshow).val(number)
		}
		
	})
}
$(document).ready(function(){
	/*公用样式默认加载*/
	defaultMinheight(".wapframe");
	$(window).resize(function(){
		defaultMinheight(".wapframe");
		//alert("fff")
	});
})