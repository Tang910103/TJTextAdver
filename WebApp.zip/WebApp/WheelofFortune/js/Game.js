﻿function getGameId(type) {
    var url = interfaceUrl + "html5.getTryMyLuckRule";
    var obj = new Object();
    obj.typeId = type;
    var callback = function (data) {
        if (successData(data)) {
            $("#hf_bill").val(data.data.billId);
            if (type == 2) {
                $("#name").html("每日可参与活动游戏" + data.data.timesOfEveryDay + "次");
                $("#hysl").html(data.data.surplusTimes);
            }
            if (data.data.billId <= 0) {
                Appalert("活动暂未开始，敬请期待！");
            }
        }
    };
    getUserToken(obj, url, callback);
}